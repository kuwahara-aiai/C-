﻿using Game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Game
{

}
public class Hello : GameChar
{
    private string type;

    public Hello(string name,int hp,string type) : base(name,hp)
    {
        this.type = type;

    }
    public override void Attack(int damage)
    {
        base.Attack(damage);
        if (hp == 0)
        {
            Console.WriteLine("==勇者よ、死んでしまうとは情けない==");
            Console.WriteLine("{0}陣の負け",type);
        }
    }
}