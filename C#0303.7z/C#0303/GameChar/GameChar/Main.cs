﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Game
{
    internal class Main1
    {
        static void Main(string[] args)
        {

            Console.WriteLine("RPGゲーム");
            Hello h = new Hello("太郎",30,"モンスター"); 
           // GameChar c = new GameChar();
            Console.WriteLine("------------------------------");
            h.ShowHP();

            while (h.HP != 0)
            {
               h.Fight();
//c.Fight();
            }

            h.EndMessage();
        }
    }
}
