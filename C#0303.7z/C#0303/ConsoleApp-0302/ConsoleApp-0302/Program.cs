﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_0302
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            string b = "kuwahara";
            Console.WriteLine("Hello {0}+{1} ", a, b);

            Person p = new Person();
            p.name = "太郎";
            p.age = 18;
            Console.WriteLine("名前:{0} 年齢:{1}", p.name, p.age);
        }
    }
}
