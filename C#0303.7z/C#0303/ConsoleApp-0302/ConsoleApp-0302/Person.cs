﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_0302
{
    internal class Person
    {

        //名前
        public string name;
        //年齢
        public int age;
    }
}
