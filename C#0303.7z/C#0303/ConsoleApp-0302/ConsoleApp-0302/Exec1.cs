﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_0302
{
    internal class Exec1
    {
        static void Main(string[] args)
        {
            int a = 5;
            string b = "桑原";
            Console.WriteLine("Hello {0}+{1} ", a, b);

            Person p = new Person();
            p.name = "愛";
            p.age = 33;
            Console.WriteLine("名前:{0} 年齢:{1}", p.name, p.age);
        }

    }
}
